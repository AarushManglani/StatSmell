// Employee.java
public class Employee {
    protected String name;
    protected double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void calculateBonus() {
        System.out.println("Bonus: " + (salary * 0.10));
    }

    public void printDetails() {
        System.out.println("Employee: " + name + ", Salary: " + salary);
    }
}
